/**
 * data.js
 * ---------------------------------------------------------------------------
 * ALL content/cadence rules live here. app.js only reads the output of
 * generateTracker() — it never hardcodes category logic. To customize:
 *
 *   1. Paste your real DSA problems into DSA_PROBLEMS (see format below).
 *   2. Edit DESIGN_PATTERNS (60 entries) with your own list/order.
 *   3. Edit PROJECTS (5 entries) with real titles/descriptions once decided.
 *   4. Edit the *_GENERIC_TASK strings/hours if your course plan changes.
 *
 * Nothing else needs to change — generateTracker() rebuilds all 60 days x
 * 8 tasks from this config every time the page loads.
 * ---------------------------------------------------------------------------
 */

const TOTAL_DAYS = 60;

/* =============================================================================
 * 1. DSA — 30 patterns, ~500 problems, 1 pattern every 2 days
 * =============================================================================
 * FORMAT for DSA_PROBLEMS: flat array of objects, one per LeetCode problem:
 *   {
 *     pattern: "Sliding Window",       // must match a name in DSA_PATTERN_ORDER,
 *                                      // or just appear in the order you want —
 *                                      // patterns are auto-detected from this
 *                                      // array in first-seen order.
 *     problem: "Longest Substring Without Repeating Characters",
 *     number: 3,                      // LeetCode problem number
 *     link: "https://leetcode.com/problems/longest-substring-without-repeating-characters/"
 *   }
 *
 * Just paste your ~500-row list here (or load it from dsa-problems.json —
 * see the loadExternalDSAData() note near the bottom of this file).
 * Patterns are taken in the order they first appear in this array, and each
 * pattern's problems are auto-split roughly in half across its 2 days.
 * If you have fewer than 30 distinct patterns represented, remaining day-pairs
 * will just show a "pattern coming soon" placeholder.
 * ============================================================================= */
const DSA_PROBLEMS = [
  // --- PLACEHOLDER SAMPLE DATA (replace with your real ~500-problem list) ---
  { pattern: "Two Pointers", problem: "Two Sum II - Input Array Is Sorted", number: 167, link: "https://leetcode.com/problems/two-sum-ii-input-array-is-sorted/" },
  { pattern: "Two Pointers", problem: "3Sum", number: 15, link: "https://leetcode.com/problems/3sum/" },
  { pattern: "Two Pointers", problem: "Container With Most Water", number: 11, link: "https://leetcode.com/problems/container-with-most-water/" },
  { pattern: "Two Pointers", problem: "Trapping Rain Water", number: 42, link: "https://leetcode.com/problems/trapping-rain-water/" },

  { pattern: "Sliding Window", problem: "Best Time to Buy and Sell Stock", number: 121, link: "https://leetcode.com/problems/best-time-to-buy-and-sell-stock/" },
  { pattern: "Sliding Window", problem: "Longest Substring Without Repeating Characters", number: 3, link: "https://leetcode.com/problems/longest-substring-without-repeating-characters/" },
  { pattern: "Sliding Window", problem: "Longest Repeating Character Replacement", number: 424, link: "https://leetcode.com/problems/longest-repeating-character-replacement/" },
  { pattern: "Sliding Window", problem: "Minimum Window Substring", number: 76, link: "https://leetcode.com/problems/minimum-window-substring/" },

  { pattern: "Fast & Slow Pointers", problem: "Linked List Cycle", number: 141, link: "https://leetcode.com/problems/linked-list-cycle/" },
  { pattern: "Fast & Slow Pointers", problem: "Middle of the Linked List", number: 876, link: "https://leetcode.com/problems/middle-of-the-linked-list/" },
  { pattern: "Fast & Slow Pointers", problem: "Happy Number", number: 202, link: "https://leetcode.com/problems/happy-number/" },
  { pattern: "Fast & Slow Pointers", problem: "Linked List Cycle II", number: 142, link: "https://leetcode.com/problems/linked-list-cycle-ii/" },

  { pattern: "Merge Intervals", problem: "Merge Intervals", number: 56, link: "https://leetcode.com/problems/merge-intervals/" },
  { pattern: "Merge Intervals", problem: "Insert Interval", number: 57, link: "https://leetcode.com/problems/insert-interval/" },
  { pattern: "Merge Intervals", problem: "Non-overlapping Intervals", number: 435, link: "https://leetcode.com/problems/non-overlapping-intervals/" },

  { pattern: "Cyclic Sort", problem: "Missing Number", number: 268, link: "https://leetcode.com/problems/missing-number/" },
  { pattern: "Cyclic Sort", problem: "Find All Numbers Disappeared in an Array", number: 448, link: "https://leetcode.com/problems/find-all-numbers-disappeared-in-an-array/" },
  { pattern: "Cyclic Sort", problem: "Find the Duplicate Number", number: 287, link: "https://leetcode.com/problems/find-the-duplicate-number/" },

  { pattern: "In-place Reversal of Linked List", problem: "Reverse Linked List", number: 206, link: "https://leetcode.com/problems/reverse-linked-list/" },
  { pattern: "In-place Reversal of Linked List", problem: "Reverse Linked List II", number: 92, link: "https://leetcode.com/problems/reverse-linked-list-ii/" },
  { pattern: "In-place Reversal of Linked List", problem: "Swap Nodes in Pairs", number: 24, link: "https://leetcode.com/problems/swap-nodes-in-pairs/" },

  { pattern: "Tree BFS", problem: "Binary Tree Level Order Traversal", number: 102, link: "https://leetcode.com/problems/binary-tree-level-order-traversal/" },
  { pattern: "Tree BFS", problem: "Binary Tree Zigzag Level Order Traversal", number: 103, link: "https://leetcode.com/problems/binary-tree-zigzag-level-order-traversal/" },

  { pattern: "Tree DFS", problem: "Path Sum", number: 112, link: "https://leetcode.com/problems/path-sum/" },
  { pattern: "Tree DFS", problem: "Path Sum II", number: 113, link: "https://leetcode.com/problems/path-sum-ii/" },
  { pattern: "Tree DFS", problem: "Diameter of Binary Tree", number: 543, link: "https://leetcode.com/problems/diameter-of-binary-tree/" },

  { pattern: "Two Heaps", problem: "Find Median from Data Stream", number: 295, link: "https://leetcode.com/problems/find-median-from-data-stream/" },
  { pattern: "Two Heaps", problem: "IPO", number: 502, link: "https://leetcode.com/problems/ipo/" },

  { pattern: "Subsets", problem: "Subsets", number: 78, link: "https://leetcode.com/problems/subsets/" },
  { pattern: "Subsets", problem: "Subsets II", number: 90, link: "https://leetcode.com/problems/subsets-ii/" },
  { pattern: "Subsets", problem: "Permutations", number: 46, link: "https://leetcode.com/problems/permutations/" },

  { pattern: "Modified Binary Search", problem: "Search in Rotated Sorted Array", number: 33, link: "https://leetcode.com/problems/search-in-rotated-sorted-array/" },
  { pattern: "Modified Binary Search", problem: "Find Minimum in Rotated Sorted Array", number: 153, link: "https://leetcode.com/problems/find-minimum-in-rotated-sorted-array/" },

  { pattern: "Bitwise XOR", problem: "Single Number", number: 136, link: "https://leetcode.com/problems/single-number/" },
  { pattern: "Bitwise XOR", problem: "Single Number II", number: 137, link: "https://leetcode.com/problems/single-number-ii/" },

  { pattern: "Top K Elements", problem: "Kth Largest Element in an Array", number: 215, link: "https://leetcode.com/problems/kth-largest-element-in-an-array/" },
  { pattern: "Top K Elements", problem: "Top K Frequent Elements", number: 347, link: "https://leetcode.com/problems/top-k-frequent-elements/" },

  { pattern: "K-way Merge", problem: "Merge k Sorted Lists", number: 23, link: "https://leetcode.com/problems/merge-k-sorted-lists/" },
  { pattern: "K-way Merge", problem: "Kth Smallest Element in a Sorted Matrix", number: 378, link: "https://leetcode.com/problems/kth-smallest-element-in-a-sorted-matrix/" },

  { pattern: "0/1 Knapsack", problem: "Partition Equal Subset Sum", number: 416, link: "https://leetcode.com/problems/partition-equal-subset-sum/" },
  { pattern: "0/1 Knapsack", problem: "Target Sum", number: 494, link: "https://leetcode.com/problems/target-sum/" },

  { pattern: "Unbounded Knapsack", problem: "Coin Change", number: 322, link: "https://leetcode.com/problems/coin-change/" },
  { pattern: "Unbounded Knapsack", problem: "Coin Change II", number: 518, link: "https://leetcode.com/problems/coin-change-ii/" },

  { pattern: "Fibonacci Numbers (DP)", problem: "Climbing Stairs", number: 70, link: "https://leetcode.com/problems/climbing-stairs/" },
  { pattern: "Fibonacci Numbers (DP)", problem: "House Robber", number: 198, link: "https://leetcode.com/problems/house-robber/" },

  { pattern: "Palindromic Subsequence", problem: "Longest Palindromic Substring", number: 5, link: "https://leetcode.com/problems/longest-palindromic-substring/" },
  { pattern: "Palindromic Subsequence", problem: "Longest Palindromic Subsequence", number: 516, link: "https://leetcode.com/problems/longest-palindromic-subsequence/" },

  { pattern: "Longest Common Substring", problem: "Longest Common Subsequence", number: 1143, link: "https://leetcode.com/problems/longest-common-subsequence/" },
  { pattern: "Longest Common Substring", problem: "Edit Distance", number: 72, link: "https://leetcode.com/problems/edit-distance/" },

  { pattern: "Backtracking", problem: "N-Queens", number: 51, link: "https://leetcode.com/problems/n-queens/" },
  { pattern: "Backtracking", problem: "Word Search", number: 79, link: "https://leetcode.com/problems/word-search/" },

  { pattern: "Graphs (BFS/DFS)", problem: "Number of Islands", number: 200, link: "https://leetcode.com/problems/number-of-islands/" },
  { pattern: "Graphs (BFS/DFS)", problem: "Clone Graph", number: 133, link: "https://leetcode.com/problems/clone-graph/" },

  { pattern: "Topological Sort", problem: "Course Schedule", number: 207, link: "https://leetcode.com/problems/course-schedule/" },
  { pattern: "Topological Sort", problem: "Course Schedule II", number: 210, link: "https://leetcode.com/problems/course-schedule-ii/" },

  { pattern: "Union Find", problem: "Number of Provinces", number: 547, link: "https://leetcode.com/problems/number-of-provinces/" },
  { pattern: "Union Find", problem: "Redundant Connection", number: 684, link: "https://leetcode.com/problems/redundant-connection/" },

  { pattern: "Trie", problem: "Implement Trie (Prefix Tree)", number: 208, link: "https://leetcode.com/problems/implement-trie-prefix-tree/" },
  { pattern: "Trie", problem: "Word Search II", number: 212, link: "https://leetcode.com/problems/word-search-ii/" },

  { pattern: "Greedy", problem: "Jump Game", number: 55, link: "https://leetcode.com/problems/jump-game/" },
  { pattern: "Greedy", problem: "Gas Station", number: 134, link: "https://leetcode.com/problems/gas-station/" },

  { pattern: "Monotonic Stack", problem: "Daily Temperatures", number: 739, link: "https://leetcode.com/problems/daily-temperatures/" },
  { pattern: "Monotonic Stack", problem: "Largest Rectangle in Histogram", number: 84, link: "https://leetcode.com/problems/largest-rectangle-in-histogram/" },

  { pattern: "Prefix Sum", problem: "Subarray Sum Equals K", number: 560, link: "https://leetcode.com/problems/subarray-sum-equals-k/" },
  { pattern: "Prefix Sum", problem: "Range Sum Query - Immutable", number: 303, link: "https://leetcode.com/problems/range-sum-query-immutable/" },

  { pattern: "Matrix Traversal", problem: "Spiral Matrix", number: 54, link: "https://leetcode.com/problems/spiral-matrix/" },
  { pattern: "Matrix Traversal", problem: "Rotate Image", number: 48, link: "https://leetcode.com/problems/rotate-image/" },

  { pattern: "Binary Search on Answer", problem: "Koko Eating Bananas", number: 875, link: "https://leetcode.com/problems/koko-eating-bananas/" },
  { pattern: "Binary Search on Answer", problem: "Capacity To Ship Packages Within D Days", number: 1011, link: "https://leetcode.com/problems/capacity-to-ship-packages-within-d-days/" },

  { pattern: "Segment Tree / BIT", problem: "Range Sum Query - Mutable", number: 307, link: "https://leetcode.com/problems/range-sum-query-mutable/" },
  { pattern: "Segment Tree / BIT", problem: "Count of Smaller Numbers After Self", number: 315, link: "https://leetcode.com/problems/count-of-smaller-numbers-after-self/" },
  // --- END PLACEHOLDER SAMPLE DATA ---
];

// Video watched at the start of each pattern (Day 1 of its pair)
const DSA_PATTERN_VIDEO_TASK = (patternName) =>
  `Watch "${patternName}" pattern overview video, then start problems below.`;

/* =============================================================================
 * 2. Java + Spring Boot — generic recurring daily task, ~72 hrs total
 * ============================================================================= */
const JAVA_SPRING_TOTAL_HOURS = 72;
const JAVA_SPRING_HOURS_PER_DAY = 1.2;
const JAVA_SPRING_GENERIC_TASK = {
  title: "Java + Spring Boot videos",
  description:
    "Watch 5–10 Java/Spring Boot interview-prep videos (~1.2 hrs). Continue sequentially from where you left off — recommended order: Code Decode → Java Techie → Java Guides.",
};

/* =============================================================================
 * 3. SQL — generic recurring daily task, ~64 hrs total
 * ============================================================================= */
const SQL_TOTAL_HOURS = 64;
const SQL_HOURS_PER_DAY = 1;
const SQL_GENERIC_TASK = {
  title: "SQL practice/videos",
  description:
    "~1 hr of SQL interview prep. Continue sequentially through your chosen playlist/course from where you left off.",
};

/* =============================================================================
 * 4. System Design — generic recurring daily task, ~45 hrs total
 * ============================================================================= */
const SYSTEM_DESIGN_TOTAL_HOURS = 45;
const SYSTEM_DESIGN_HOURS_PER_DAY = 1;
const SYSTEM_DESIGN_GENERIC_TASK = {
  title: "System Design study",
  description:
    "~1 hr of System Design content (HLD/LLD case studies, scalability concepts). Continue sequentially from where you left off.",
};

/* =============================================================================
 * 5. Design Patterns — 60 total (30 HLD + 30 LLD/GoF), 1 per day
 * Edit this array directly to reorder or replace with your own list.
 * ============================================================================= */
const DESIGN_PATTERNS = [
  // --- High-Level / System Design patterns (Days 1-30 by default) ---
  { name: "Load Balancing", type: "High-Level" },
  { name: "Caching Strategies", type: "High-Level" },
  { name: "Database Sharding", type: "High-Level" },
  { name: "Database Replication", type: "High-Level" },
  { name: "CQRS", type: "High-Level" },
  { name: "Event Sourcing", type: "High-Level" },
  { name: "API Gateway", type: "High-Level" },
  { name: "Rate Limiting", type: "High-Level" },
  { name: "Circuit Breaker", type: "High-Level" },
  { name: "Message Queues (Pub/Sub)", type: "High-Level" },
  { name: "Content Delivery Networks (CDN)", type: "High-Level" },
  { name: "Consistent Hashing", type: "High-Level" },
  { name: "Leader Election", type: "High-Level" },
  { name: "Data Partitioning", type: "High-Level" },
  { name: "Microservices Decomposition", type: "High-Level" },
  { name: "Saga Pattern", type: "High-Level" },
  { name: "Strangler Fig Pattern", type: "High-Level" },
  { name: "Bulkhead Pattern", type: "High-Level" },
  { name: "Sidecar Pattern", type: "High-Level" },
  { name: "Service Discovery", type: "High-Level" },
  { name: "Write-Ahead Log", type: "High-Level" },
  { name: "Read Replica / CQRS Read Models", type: "High-Level" },
  { name: "Idempotency Keys", type: "High-Level" },
  { name: "Backpressure", type: "High-Level" },
  { name: "Multi-Region Active-Active", type: "High-Level" },
  { name: "Blue-Green Deployment", type: "High-Level" },
  { name: "Canary Releases", type: "High-Level" },
  { name: "Feature Flags", type: "High-Level" },
  { name: "Distributed Locking", type: "High-Level" },
  { name: "CAP Theorem Trade-offs", type: "High-Level" },

  // --- Low-Level / GoF patterns (Days 31-60 by default) ---
  { name: "Singleton", type: "Low-Level (GoF)" },
  { name: "Factory Method", type: "Low-Level (GoF)" },
  { name: "Abstract Factory", type: "Low-Level (GoF)" },
  { name: "Builder", type: "Low-Level (GoF)" },
  { name: "Prototype", type: "Low-Level (GoF)" },
  { name: "Adapter", type: "Low-Level (GoF)" },
  { name: "Bridge", type: "Low-Level (GoF)" },
  { name: "Composite", type: "Low-Level (GoF)" },
  { name: "Decorator", type: "Low-Level (GoF)" },
  { name: "Facade", type: "Low-Level (GoF)" },
  { name: "Flyweight", type: "Low-Level (GoF)" },
  { name: "Proxy", type: "Low-Level (GoF)" },
  { name: "Chain of Responsibility", type: "Low-Level (GoF)" },
  { name: "Command", type: "Low-Level (GoF)" },
  { name: "Interpreter", type: "Low-Level (GoF)" },
  { name: "Iterator", type: "Low-Level (GoF)" },
  { name: "Mediator", type: "Low-Level (GoF)" },
  { name: "Memento", type: "Low-Level (GoF)" },
  { name: "Observer", type: "Low-Level (GoF)" },
  { name: "State", type: "Low-Level (GoF)" },
  { name: "Strategy", type: "Low-Level (GoF)" },
  { name: "Template Method", type: "Low-Level (GoF)" },
  { name: "Visitor", type: "Low-Level (GoF)" },
  { name: "Null Object", type: "Low-Level (GoF)" },
  { name: "Dependency Injection", type: "Low-Level (GoF)" },
  { name: "Object Pool", type: "Low-Level (GoF)" },
  { name: "Specification", type: "Low-Level (GoF)" },
  { name: "Repository", type: "Low-Level (GoF)" },
  { name: "Unit of Work", type: "Low-Level (GoF)" },
  { name: "MVC / MVP / MVVM", type: "Low-Level (GoF)" },
];

/* =============================================================================
 * 6. Projects — 5 total, 1 every 12 days. Fill in real details later.
 * ============================================================================= */
const PROJECTS = [
  { title: "Project 1", description: "TBD — placeholder. Edit this in data.js." },
  { title: "Project 2", description: "TBD — placeholder. Edit this in data.js." },
  { title: "Project 3", description: "TBD — placeholder. Edit this in data.js." },
  { title: "Project 4", description: "TBD — placeholder. Edit this in data.js." },
  { title: "Project 5", description: "TBD — placeholder. Edit this in data.js." },
];
const DAYS_PER_PROJECT = 12;

/* =============================================================================
 * 7. AI — 6 courses (~110 hrs) + ~10 hrs supplementary, 2 hrs/day
 * ============================================================================= */
const AI_COURSE_HOURS = 110;
const AI_SUPPLEMENTARY_HOURS = 10;
const AI_TOTAL_HOURS = AI_COURSE_HOURS + AI_SUPPLEMENTARY_HOURS;
const AI_HOURS_PER_DAY = 2;
const AI_GENERIC_TASK = {
  title: "AI courses",
  description: "2 hrs of AI coursework/videos. Continue from where you left off across your 6 courses + supplementary YouTube content.",
};

/* =============================================================================
 * 8. Random Stuff — free-text/checkbox, no fixed source
 * ============================================================================= */
const RANDOM_STUFF_TASK = {
  title: "Random Stuff",
  description: "Watch or read one interesting/random tech thing today — anything that caught your eye.",
};

/* =============================================================================
 * CATEGORY METADATA (order, labels, colors used by the UI)
 * ============================================================================= */
const CATEGORIES = [
  { key: "dsa", label: "DSA" },
  { key: "java_spring", label: "Java+SpringBoot" },
  { key: "sql", label: "SQL" },
  { key: "system_design", label: "System Design" },
  { key: "design_patterns", label: "Design Patterns" },
  { key: "projects", label: "Projects" },
  { key: "ai", label: "AI" },
  { key: "random", label: "Random Stuff" },
];

/* =============================================================================
 * GENERATION LOGIC — builds the 60 x 8 structure from the config above.
 * Returns: { days: [ { day, tasks: [ {category, title, description, link} x8 ] } ] }
 * ============================================================================= */
function buildDSASchedule() {
  // Group problems by pattern, preserving first-seen order.
  const order = [];
  const byPattern = new Map();
  for (const p of DSA_PROBLEMS) {
    if (!byPattern.has(p.pattern)) {
      byPattern.set(p.pattern, []);
      order.push(p.pattern);
    }
    byPattern.get(p.pattern).push(p);
  }

  // schedule[day] = { patternName, videoTask (bool), problems: [...] }
  const schedule = {};
  for (let i = 0; i < 30; i++) {
    const day1 = i * 2 + 1;
    const day2 = i * 2 + 2;
    const patternName = order[i]; // undefined if fewer than 30 patterns supplied
    if (!patternName) {
      schedule[day1] = { patternName: null, problems: [], isVideoDay: false };
      schedule[day2] = { patternName: null, problems: [], isVideoDay: false };
      continue;
    }
    const problems = byPattern.get(patternName);
    const mid = Math.ceil(problems.length / 2);
    schedule[day1] = { patternName, problems: problems.slice(0, mid), isVideoDay: true };
    schedule[day2] = { patternName, problems: problems.slice(mid), isVideoDay: false };
  }
  return schedule;
}

function generateTracker() {
  const dsaSchedule = buildDSASchedule();
  const days = [];

  for (let d = 1; d <= TOTAL_DAYS; d++) {
    const tasks = [];

    // 1. DSA
    const dsaInfo = dsaSchedule[d];
    if (dsaInfo && dsaInfo.patternName) {
      const problemLines = dsaInfo.problems
        .map((p) => `#${p.number} ${p.problem}`)
        .join(", ");
      const videoNote = dsaInfo.isVideoDay ? DSA_PATTERN_VIDEO_TASK(dsaInfo.patternName) + " " : "";
      tasks.push({
        category: "dsa",
        title: `${dsaInfo.patternName} — ${dsaInfo.isVideoDay ? "Day 1/2" : "Day 2/2"}`,
        description: `${videoNote}Problems: ${problemLines || "(no problems loaded yet for this pattern)"}`,
        link: dsaInfo.problems[0] ? dsaInfo.problems[0].link : null,
        subLinks: dsaInfo.problems.map((p) => ({ label: `#${p.number} ${p.problem}`, url: p.link })),
      });
    } else {
      tasks.push({
        category: "dsa",
        title: "DSA — pattern not yet loaded",
        description: "Paste your DSA_PROBLEMS list in data.js to populate this day.",
        link: null,
      });
    }

    // 2. Java + Spring Boot
    const jsHoursDone = (d - 1) * JAVA_SPRING_HOURS_PER_DAY;
    const jsHoursLeft = Math.max(0, JAVA_SPRING_TOTAL_HOURS - jsHoursDone).toFixed(1);
    tasks.push({
      category: "java_spring",
      title: JAVA_SPRING_GENERIC_TASK.title,
      description: `${JAVA_SPRING_GENERIC_TASK.description} (~${jsHoursLeft} hrs remaining in the plan as of today.)`,
      link: null,
    });

    // 3. SQL
    const sqlHoursDone = (d - 1) * SQL_HOURS_PER_DAY;
    const sqlHoursLeft = Math.max(0, SQL_TOTAL_HOURS - sqlHoursDone).toFixed(1);
    tasks.push({
      category: "sql",
      title: SQL_GENERIC_TASK.title,
      description: `${SQL_GENERIC_TASK.description} (~${sqlHoursLeft} hrs remaining in the plan as of today.)`,
      link: null,
    });

    // 4. System Design
    const sdHoursDone = (d - 1) * SYSTEM_DESIGN_HOURS_PER_DAY;
    const sdHoursLeft = Math.max(0, SYSTEM_DESIGN_TOTAL_HOURS - sdHoursDone).toFixed(1);
    const sdExhausted = sdHoursDone >= SYSTEM_DESIGN_TOTAL_HOURS;
    tasks.push({
      category: "system_design",
      title: SYSTEM_DESIGN_GENERIC_TASK.title,
      description: sdExhausted
        ? `${SYSTEM_DESIGN_GENERIC_TASK.description} (Plan's ~${SYSTEM_DESIGN_TOTAL_HOURS} hrs are used up — keep going with extra HLD/LLD case studies of your choice.)`
        : `${SYSTEM_DESIGN_GENERIC_TASK.description} (~${sdHoursLeft} hrs remaining in the plan as of today.)`,
      link: null,
    });

    // 5. Design Patterns
    const pattern = DESIGN_PATTERNS[d - 1];
    tasks.push({
      category: "design_patterns",
      title: pattern ? `${pattern.name} (${pattern.type})` : "Pattern not configured",
      description: pattern
        ? `Study and implement a small example of the "${pattern.name}" pattern.`
        : "Add a 60th entry to DESIGN_PATTERNS in data.js.",
      link: null,
    });

    // 6. Projects
    const projIndex = Math.floor((d - 1) / DAYS_PER_PROJECT);
    const dayWithinProject = ((d - 1) % DAYS_PER_PROJECT) + 1;
    const proj = PROJECTS[projIndex];
    tasks.push({
      category: "projects",
      title: proj ? `${proj.title} — Day ${dayWithinProject}/${DAYS_PER_PROJECT}` : "Project not configured",
      description: proj ? proj.description : "Add a 5th project to PROJECTS in data.js.",
      link: null,
    });

    // 7. AI
    const aiHoursDone = (d - 1) * AI_HOURS_PER_DAY;
    const aiHoursLeft = Math.max(0, AI_TOTAL_HOURS - aiHoursDone).toFixed(1);
    tasks.push({
      category: "ai",
      title: AI_GENERIC_TASK.title,
      description: `${AI_GENERIC_TASK.description} (~${aiHoursLeft} hrs remaining in the plan as of today.)`,
      link: null,
    });

    // 8. Random Stuff
    tasks.push({
      category: "random",
      title: RANDOM_STUFF_TASK.title,
      description: RANDOM_STUFF_TASK.description,
      link: null,
    });

    days.push({ day: d, tasks });
  }

  return { days, categories: CATEGORIES, totalDays: TOTAL_DAYS };
}

/* =============================================================================
 * OPTIONAL: load DSA_PROBLEMS from an external dsa-problems.json at runtime
 * instead of hardcoding it above. If present, this overrides the sample data.
 * Call `await loadExternalDSAData()` before `generateTracker()` in app.js if
 * you want to use this. Otherwise the sample data above is used directly.
 * ============================================================================= */
async function loadExternalDSAData() {
  try {
    const res = await fetch("./dsa-problems.json", { cache: "no-store" });
    if (!res.ok) return false;
    const externalProblems = await res.json();
    if (Array.isArray(externalProblems) && externalProblems.length > 0) {
      DSA_PROBLEMS.length = 0;
      DSA_PROBLEMS.push(...externalProblems);
      return true;
    }
  } catch (e) {
    // no external file present — fall back to sample data silently
  }
  return false;
}

// Expose to app.js (plain <script> include, no bundler)
window.TrackerData = {
  generateTracker,
  loadExternalDSAData,
  CATEGORIES,
  TOTAL_DAYS,
  DESIGN_PATTERNS,
  PROJECTS,
  DSA_PROBLEMS,
};
